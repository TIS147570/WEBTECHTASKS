<html>
	<head></head>
	<body>
		<h2>Your name is <?php echo $_COOKIE["Loggedinuser"];?><br> 
		Your password is <?php echo $_COOKIE["Loggedinpassword"];?>
		<br>You are a <?php echo $_COOKIE["type"];?>
	</body>
</html>