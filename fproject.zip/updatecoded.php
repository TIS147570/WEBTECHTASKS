<?php
$uname = $_POST['username'];
$password = $_POST['password'];
$gender = $_POST['gender'];
$email = $_POST['email'];
$bloodgroup = $_POST['bloodgroup'];
$phoneCode = $_POST['phoneCode'];
$phone = $_POST['phone'];
$type = "user";
if (!empty($uname) || !empty($password) || !empty($gender) || !empty($email) || !empty($phoneCode) || !empty($phone)) {
	
	
	
$servername = "localhost";
		$username = "root";
		$pass = "";
		$dbname = "userinfo";
		try {
 $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $pass);
  // set the PDO error mode to exception
  $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
  $sql = "UPDATE `user` SET `username`='$uname',`password`='$password',`gender`='$gender',
  `phoneCode`='$phoneCode',`phone`='$phone',`type`='$type',`bloodgroup`='$bloodgroup',`other`='null' WHERE email='$email';";
  // use exec() because no results are returned
  $conn->exec($sql);
  echo "Updated successfully";
} catch(PDOException $e) {
  echo $sql . "<br>" . $e->getMessage();
}

$conn = null;
	
}?>