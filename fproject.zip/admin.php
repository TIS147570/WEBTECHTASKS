<html>
	<head>
		<title>Admin Home</title>
	</head>
	<body>
		<h2>Admin Home</h2>

<h4><a href="deleted.php">Delete A Donar</a></h4>
<h4><a href="deleteu.php">Delete A User</a></h4>
<h2><a href="updatedonar.php">Update A Donar</a></h2>
<h2><a href="updateuser.php">Update A User</a></h2>
</body>
</html>