<html>
	<head>
		<title>User Home</title>
	</head>
	<body>
		<h2>Usr Home</h2>

<h4><a href="showpass.php">Show Password</a></h4>


</body>
</html>