<!DOCTYPE HTML>
<html>
<head>
  <title>Update User Form</title>
</head>
<body>
 <form action="updatecodeus.php" method="POST">
  <table>
  <tr>
    <td>Email :</td>
    <td><input type="email" name="email" required></td>
   </tr> 
   <tr>
    <td>Name :</td>
    <td><input type="text" name="username" required></td>
   </tr>
   <tr>
		<td><span>Password:</span></td>
		<td><input type="password" name="password" required></td>
		</tr>
   <tr>
    <td>Gender :</td>
    <td>
     <input type="radio" name="gender" value="m" required>Male
     <input type="radio" name="gender" value="f" required>Female
    </td>
   </tr>
   
   <tr>
    <td>Phone no :</td>
    <td>
     <select name="phoneCode" required>
      <option selected hidden value="">Select Code</option>
      <option value="017">017</option>
      <option value="018">018</option>
      <option value="019">019</option>
      <option value="013">013</option>
      <option value="015">015</option>
     </select>
     <input type="phone" name="phone" required>
    </td>
   </tr>
   <tr>
    <td><input type="submit" value="Update"></td>
   </tr>
  </table>
 </form>
</body>
</html>