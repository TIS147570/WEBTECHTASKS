<?php
	$uname="";
	$password="";
	if(isset($_POST["Login"]))
	{
        $uname=$_POST["uname"];
        $password=$_POST["password"];
		
		$servername = "localhost";
		$username = "root";
		$pass = "";
		$dbname = "userinfo";
			
		$conn = mysqli_connect($servername,$username,$pass,$dbname);
			
		$query = "SELECT * FROM user WHERE username='$uname' and password='$password'";
			
		$result = mysqli_query($conn,$query);
			
		if(mysqli_num_rows($result)){
			$var = mysqli_fetch_assoc($result);
				
			if($var["type"] == "admin"){
				header("Location: admin.php");
				setcookie("Loggedinuser",$uname,time()+60);
				setcookie("type",$var["type"],time()+60);
				setcookie("Loggedinpassword",$password,time()+60);
			}
			else if($var["type"] == "user"){
				header("Location: user.php");
				setcookie("Loggedinuser",$uname,time()+60);
				setcookie("type",$var["type"],time()+60);
				setcookie("Loggedinpassword",$password,time()+60);
            }
            else if($var["type"] == "donar"){
				header("Location: donar.php");
				setcookie("Loggedinuser",$uname,time()+60);
				setcookie("type",$var["type"],time()+60);
				setcookie("Loggedinpassword",$password,time()+60);
			}
			else{
				echo " Unknown Users Cannot Login";
			}
		}
		else{
			echo "User Name or Password is Wrong";
		}
		
	}
?>
<html>
	<head>
		<title>LoginFrom</title>
	</head>
	<body>
		<h2>Login Form</h2>
		<form action="" method="post">
			<table>
				<tr>
					<td><span>Username:</span></td>
					<td><input type="text" name="uname"value="<?php echo $uname; ?>" required></td>
				</tr>
				<tr>
					<td><span>Password:</span></td>
					<td><input type="text" name="password"value="<?php echo $password; ?>" required></td>
				</tr>
				<tr>
					<td><label style= "color:red"><a href = "forgotpass.php">Forgot password?</a></label></td>
					<td><input type="submit" name="Login" value="Login"></td>
				</tr>
			</table>
		</form>
		<h2><a href="ruser.php">Register as A User</a></h2><br>
		<h2><a href="rdonar.php">Register as A Donar</a></h2>
		
		
		
	</body>
</html>