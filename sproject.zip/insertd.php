<?php
$uname = $_POST['username'];
$password = $_POST['password'];
$gender = $_POST['gender'];
$email = $_POST['email'];
$bloodgroup = $_POST['bloodgroup'];
$phoneCode = $_POST['phoneCode'];
$phone = $_POST['phone'];
$type = "user";
if (!empty($username) || !empty($password) || !empty($gender) || !empty($email) || !empty($phoneCode) || !empty($phone)) {
	
$servername = "localhost";
		$username = "root";
		$pass = "";
		$dbname = "userinfo";
		try {
 $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $pass);
  // set the PDO error mode to exception
  $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
  $sql = "INSERT INTO `user` (`username`, `password`, `gender`, `email`, `phoneCode`, `phone`, `type`, `bloodgroup`, `other`)
  VALUES ('$uname', '$password', '$gender', '$email', '$phoneCode', '$phone', '$type', '$bloodgroup', NULL);";
  // use exec() because no results are returned
  $conn->exec($sql);
  echo "New record created successfully";
} catch(PDOException $e) {
  echo $sql . "<br>" . $e->getMessage();
}

$conn = null;
	
    /*if (mysqli_connect_error()) {
     die('Connect Error('. mysqli_connect_errno().')'. mysqli_connect_error());
    } else {
     $SELECT = "SELECT email From user Where email = ? Limit 1";
     $INSERT = "INSERT Into donar (username, password, gender, email, phoneCode, phone, type, bloodgroup) values(?, ?, ?, ?, ?, ?, ?, ?)";
     //Prepare statement
     $stmt = $conn->prepare($SELECT);
     $stmt->bind_param("s", $email);
     $stmt->execute();
     $stmt->bind_result($email);
     $stmt->store_result();
     $rnum = $stmt->num_rows;
     if ($rnum==0) {
      $stmt->close();
      $stmt = $conn->prepare($INSERT);
      $stmt->bind_param("ssssii", $username, $password, $gender, $email, $bloodgroup, $phoneCode, $phone, $type, $bloodgroup);
      $stmt->execute();
      echo "New record inserted sucessfully";
     } else {
      echo "Someone already register using this email";
     }
     $stmt->close();
     $conn->close();
    }
} else {
 echo "All field are required";
 die();
}*/}
?>