<!DOCTYPE HTML>
<html>
<head>
  <title>Delete User Form</title>
</head>
<body>
 <form action="deleteuser.php" method="POST">
  <table>
   <tr>
    <td>Enter User Email :</td>
    <td><input type="text" name="email" required></td>
   </tr>
   <tr>
    <td><input type="submit" value="Delete"></td>
   </tr>
  </table>
 </form>
</body>
</html>