<?php
	$servername = "localhost";
	$username = "root";
	$pass = "";
	$dbname = "userinfo";		
	$conn = mysqli_connect($servername,$username,$pass,$dbname);			
	$query = "SELECT * FROM `user` WHERE type='user'";
	$result = mysqli_query($conn,$query);
	while($var = mysqli_fetch_assoc($result)){
		echo $var["Name"] ." " .$var["Password"]." ". $var["Type"]."<br>";
	}
?>