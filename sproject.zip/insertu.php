<?php
$uname = $_POST['username'];
$password = $_POST['password'];
$gender = $_POST['gender'];
$email = $_POST['email'];
$phoneCode = $_POST['phoneCode'];
$phone = $_POST['phone'];
$type = "user";
if (!empty($uname) || !empty($pass) || !empty($gender) || !empty($email) || !empty($phoneCode) || !empty($phone)) {
	
	
	
$servername = "localhost";
		$username = "root";
		$pass = "";
		$dbname = "userinfo";
		try {
 $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $pass);
  // set the PDO error mode to exception
  $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
  $sql = "INSERT INTO `user` (`username`, `password`, `gender`, `email`, `phoneCode`, `phone`, `type`, `bloodgroup`, `other`)
  VALUES ('$uname', '$password', '$gender', '$email', '$phoneCode', '$phone', '$type', NULL, NULL);";
  // use exec() because no results are returned
  $conn->exec($sql);
  echo "New record created successfully";
} catch(PDOException $e) {
  echo $sql . "<br>" . $e->getMessage();
}

$conn = null;
	
		 /*$conn = mysqli_connect($servername,$username,$pass,$dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

$sql = "INSERT INTO user (username, password, gender, email, phoneCode, phone,type)
VALUES ($uname, $password, $gender, $email, $phoneCode, $phone, $type)";

if ($conn->query($sql) === TRUE) {
  echo "New record created successfully";
} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();*/}?>