<?php
$email = $_POST['email'];
$type = "user";
if (!empty($email)){

$servername = "localhost";
		$username = "root";
		$pass = "";
		$dbname = "userinfo";
		try {
 $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $pass);
  // set the PDO error mode to exception
  $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
  $sql = "DELETE FROM `user` WHERE email='$email' AND type='$type';";
  // use exec() because no results are returned
 if( $conn->exec($sql)){
 echo "User Deleted successfully";}
 else{ echo "User Deleted successfully";}
} catch(PDOException $e) {
  echo $sql . "<br>" . $e->getMessage();
}

$conn = null;
	
}
else{echo"enter correct mail";}


?>