<html>
<body>
<?php
	$mark=88;
	if($mark>=90 & $mark <=100)
		echo "Your Grade is A+";
	elseif($mark>80 & $mark<90)
		echo "Your Grade is A";
	elseif($mark>70 & $mark<=80)
		echo "Your Grade is B";
	elseif($mark>60 & $mark<=70)
		echo "Your Grade is C";
	elseif($mark<=60 & $mark>=0)
		echo "Your Grade is F";
	else
		echo "Error Input!!!";
?>
</body>
</html>