<html>
<body>
<?php
    $name="rara";
	
	if($name=="raju" or $name =="mina" or $name=="mithu"){
		
	echo "<b>hello</b>";	
		
	}
	else{
		    echo "<span style= 'color:red'>You are not recognized</span>";
				
				
		}


?>
</body>
</html>