<html>
<body>
<?php
	$length=6;
	$width=6;
	if($length==$width){
		
		echo "The shape is a square <br>";
		$a=$length*$width;
		$p=4*$length;
		echo "The Area is $a  <br>";
		
		echo "The Peremeter is $p";
	}
	else{
		$p=2*($length+$width);
		$a=$length*$width;
		echo "The Area is $a  <br>";
		
		echo "The Peremeter is $p";
		
	}
?>
</body>
</html>