<html>
    <body>
      "A quick brown 
      <?php
        echo "<b>fox </b>";
      ?>
        jumps over the lazy 
      <?php
        echo "<b>dog </b>";
      ?> "
    </body>
</html>